<?php
namespace app\cars;

use Exception;
use lib\response;

/**
 * Klasse cars für die Verwaltung von Autodaten.
 */
class cars
{
    /**
     * Modell - Klasse für DB - Zugriffe.
     * 
     * @var model $model
     */
    private model $model;

    /**
     * Konstruktor der Klasse cars.
     *
     * @param string $methode   Die Methode, die aufgerufen werden soll.
     * @param string $parameter Der Parameter, der der Methode übergeben wird.
     */
    public function __construct(string $methode = "", string $parameter = "")
    {
        $this->model = new model();
        if (!empty($methode) && method_exists(object_or_class: $this, method: $methode)) {
            try {
                $this->$methode($parameter);
            } catch (Exception $e) {
                response::errorJSON(array: ["error" => $e->getMessage()]);
            }
        } else {
            $this->init();
        }
    }

    /**
     * Holt Daten aus der Datenbank basierend auf der ID und gibt eine JSON-Antwort zurück.
     *
     * Diese Methode gibt keine Daten direkt zurück, sondern sendet eine JSON-Antwort
     * an den Client über die `response`-Klasse.
     *
     * @param string $id Die ID des Autos (optional). Wenn leer, werden alle Autos abgerufen.
     * @return void
     */
    public function getData(string $id): void
    {
        if ($id === "") {
            $result = $this->model->getData();
        } else {
            $result = $this->model->getData(id: $id);
        }

        if ($result) {
            response::successJSON(array: ["data" => $result, "count" => count($result), "success" => "Daten erfolgreich abgerufen."]);

        } else {
            response::errorJSON(array: ["error" => "Keine Daten gefunden."]);
        }
    }

    /**
     * Fügt neue Daten in die Datenbank ein.
     * 
     * Diese Methode gibt keine Daten direkt zurück, sondern sendet eine JSON-Antwort
     * an den Client über die `response`-Klasse.
     *
     * @return void
     */
    public function insertData(): void
    {
        // Überprüfe, ob POST-Daten vorhanden sind
        if (empty($_POST)) {
            echo "Fehler: Keine POST-Daten vorhanden.\n";
            return;
        } else {
            $carData = [
                "name" => "Skoda",
                "price" => 35000,
                "kraftstoff" => "Benzin",
                "farbe" => "#123456",
                "bauart" => "Limousine",
                "tank" => 0,
                "jahrgang" => "2023-01-01"
            ];

            $sql = "INSERT INTO cars (name, price, kraftstoff, farbe, bauart, tank, jahrgang) 
                    VALUES (:name, :price, :kraftstoff, :farbe, :bauart, :tank, :jahrgang)";

            try {
                $this->model->execute($sql, $carData);
                response::successJSON(array: ["success" => "Eintrag erfolgreich hinzugefügt."]);
            } catch (Exception $e) {
                response::errorJSON(array: ["error" => "Fehler beim Hinzufügen: " . $e->getMessage()]);
            }
        }
    }

    /**
     * Aktualisiert bestehende Daten in der Datenbank.
     * 
     * Diese Methode gibt keine Daten direkt zurück, sondern sendet eine JSON-Antwort
     * an den Client über die `response`-Klasse.
     *
     * @return void
     */
    public function updateData(): void
    {
        $carData = [
            "id" => 1,  // Beispiel-ID, anpassen
            "name" => "Skoda Superb",
            "price" => 36000
        ];

        $sql = "UPDATE cars SET name = :name, price = :price WHERE id = :id";

        try {
            $this->model->execute($sql, $carData);
            response::successJSON(array: ["success" => "Eintrag erfolgreich aktualisiert."]);
        } catch (Exception $e) {
            response::errorJSON(array: ["error" => "Fehler beim Aktualisieren: " . $e->getMessage()]);
        }
    }

    /**
     * Löscht Daten aus der Datenbank.
     * 
     * Diese Methode gibt keine Daten direkt zurück, sondern sendet eine JSON-Antwort
     * an den Client über die `response`-Klasse.
     *
     * @return void
     */
    public function deleteData(): void
    {
        $carId = 1;

        $sql = "DELETE FROM cars WHERE id = :id";

        try {
            $this->model->execute($sql, ["id" => $carId]);
            response::successJSON(array: ["success" => "Eintrag erfolgreich gelöscht."]);
        } catch (Exception $e) {
            response::errorJSON(array: ["error" => "Fehler beim Löschen: " . $e->getMessage()]);
        }
    }

    /**
     * Destruktor der Klasse cars.
     */
    public function __destruct()
    {
        // Optionaler Destruktor
    }

    /**
     * Zeigt die Daten in einem formatieren Format an.
     *
     * @param mixed $data Die anzuzeigenden Daten.
     * @return void
     */
    public function showData(mixed $data): void
    {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }

    /**
     * Initialisierungsmethode.
     *
     * @return void
     */
    public function init(): void
    {

    }
}
