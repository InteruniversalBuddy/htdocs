<?php
namespace lib;

use Exception;
use PDO;
use PDOException;


abstract class request
{

    public static function ValidCountry($country): bool
    {
        $country = strtoupper(string: $country);
        $countries = array("CH", "DE", "AT");
        if (in_array(needle: $country, haystack: $countries)) {
            return true;
        } else {
            return false;
        }
    }
    public static function CoutryCode($ip): mixed{
        $url = "http://ip-api.com/json/".$ip;
        $json = file_get_contents(filename: $url);
        $data = json_decode(json: $json);
        return $data->countryCode;
    }

    public static function ValidIP($ip): bool
    {
        if (filter_var(value: $ip, filter: FILTER_VALIDATE_IP)) {
            return true;
        } else {
            return false;
        }
    }

}