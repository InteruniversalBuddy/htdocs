<?php
//error_reporting(error_level: 0);
//ini_set(option: 'display_errors', value: '0');
//ini_set(option: 'display_startup_errors', value: '0');
//trigger_error(message: "Testwarnung", error_level: E_USER_WARNING);

include "./../lib/database.php";
include "./../app/cars/model.php";
include "./../app/cars/cars.php";
include "./../lib/response.php";
include "./../lib/request.php";

/**
 * Testet die Funktionalität des `getData`-Aufrufs des `cars`-Controllers.
 *
 * Dieses Skript testet die Methode `getData()` des `cars`-Controllers, um sicherzustellen,
 * dass die Ausgabe in einem gültigen JSON-Format erfolgt. Die Ausgabe wird in eine Variable
 * umgeleitet und anschließend validiert.
 *
 * @return void
 */
function TestgetData(): void {

    // ANSI-Farbcode für grün und rot
    $green = "\033[32m"; // Grün
    $red = "\033[31m";   // Rot
    $yellow = "\033[33m"; // Gelb
    $reset = "\033[0m";  // Rücksetzen auf Standardfarbe

    // Erstelle eine Instanz des `cars` Controllers
    $carController = new \app\cars\cars();

    // Ausgabe in den Puffer umleiten
    ob_start();
    
    // Aufruf der getData-Methode, um alle Daten abzurufen
    $carController->getData("3");
    
    // Pufferinhalt in eine Variable schreiben und den Puffer leeren
    $jsonOutput = ob_get_clean();
    
    // Überprüfe, ob die Ausgabe gültiges JSON ist
    $decodedJson = json_decode(json: $jsonOutput, associative: true); // JSON in ein assoziatives Array dekodieren
    if ($decodedJson !== null) {
        echo "$green::::::::::::::::::::::::::::>> Die Ausgabe ist ein gültiges JSON.\n$reset";
       
        if (isset($decodedJson['error'])) {
            echo "$red::::::::::::::::::::::::::::>> Fehler: " . $decodedJson['error'] . " \n$reset";
        } else{
            echo "$green::::::::::::::::::::::::::::>> Kein Fehler aufgetreten.\n$reset";
            echo "JSON-Ausgabe:\n";
            print_r(value: $decodedJson);
            echo "\n";
        }

        if (isset($decodedJson['status']) && $decodedJson['status'] === 'success') {
            echo "$green::::::::::::::::::::::::::::>>  Alles ok: Erfolgreiche Antwort.\n$reset";
            if (isset($decodedJson['data']) && count(value: $decodedJson['data']) > 0) {
                echo "$green::::::::::::::::::::::::::::>>  Es wurden " . count(value: $decodedJson['data']) . " Datensätze abgerufen.\n$reset";
            }
        } 
    } else {
        echo "$red::::::::::::::::::::::::::::>>  Die Ausgabe ist kein gültiges JSON.\n";
    }
    
    echo "$yellow --> getData-Tests abgeschlossen.\n";
    echo $reset;
}

// Starte die Testfunktionen
TestgetData();
