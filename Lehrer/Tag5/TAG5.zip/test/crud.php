<?php
error_reporting(error_level: 1);
ini_set(option: 'display_errors', value: '1');
ini_set(option: 'display_startup_errors', value: '1');


include "./../lib/database.php";
include "./../app/cars/model.php";
include "./../app/cars/cars.php";
include "./../lib/response.php";
include "./../lib/request.php";

/**
 * Test-Skript für die CRUD-Funktionen des `cars`-Controllers.
 */
function crud(): void {
    echo "Starte CRUD-Tests...\n";

    // Erstelle eine Instanz des `cars` Controllers
    $carController = new \app\cars\cars();

    // Teste das Einfügen von Daten
    echo "Test: Daten einfügen...\n";
    // Simuliere POST-Daten
    $_POST = [
        "name" => "Volkswagen",
        "price" => 28000,
        "kraftstoff" => "Diesel",
        "farbe" => "#654321",
        "bauart" => "Kombi",
        "tank" => 1,
        "jahrgang" => "2022-05-01"
    ];
    // Teste das Einfügen von Daten mit POST
    echo "Test: Daten einfügen mit POST-Daten...\n";
    if (!empty($_POST)) {
        $carController->insertData();
    }

    // Teste das Abrufen von Daten
    echo "Test: Daten abrufen...\n";
    // Ausgabe in den Puffer umleiten
    ob_start();
    $carController->getData("");
    // Pufferinhalt in eine Variable schreiben und den Puffer leeren
    $jsonOutput = ob_get_clean();
    if (json_decode($jsonOutput) !== null) {
        echo "Die Ausgabe ist gültiges JSON.\n";
        echo $jsonOutput;
    } else {
        echo "Die Ausgabe ist kein gültiges JSON.\n";
    }

    // Teste das Aktualisieren von Daten
    echo "Test: Daten aktualisieren...\n";
    $carController->updateData();

    // Teste das Löschen von Daten
    echo "Test: Daten löschen...\n";
    $carController->deleteData();

    // Teste das Abrufen von Daten nach dem Löschen
    echo "Test: Daten abrufen nach dem Löschen...\n";
    $carController->getData("");

    echo "CRUD-Tests abgeschlossen.\n";
}

// Starte die Testfunktionen
crud();
